Luscent One-Page Website

Files included:
- index.html
- README.txt
- images/aurora.jpg (placeholder)
- images/noire.jpg (placeholder)

Instructions:
1. Replace the WhatsApp number in index.html:
   Find the links like:
     https://wa.me/919876543210?text=Hi%20Luscent!%20I%20want%20to%20order%20Luscent%20Aurora.
   Replace '919876543210' with your number including country code (no + or spaces).
   Example India: 919812345678

2. Replace product images:
   Put your product photos into the images/ folder named aurora.jpg and noire.jpg, or change the paths in index.html.

3. Hosting (quick options):
   - GitHub Pages: create a repo, upload files, and enable Pages in repo settings.
   - Netlify: drag & drop the folder in Netlify Drop (recommended for beginners).
   - Vercel: connect repo or use manual deploy.

4. To edit prices, text, or colors:
   Open index.html in a code editor and change content or CSS variables at the top (--luxury-green, etc).

Need help deploying? Reply and I can guide you step-by-step or prepare a hosted preview.
